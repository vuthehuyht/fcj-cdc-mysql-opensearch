package tech.vuthehuyht.blogrestapi.services.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;
import tech.vuthehuyht.blogrestapi.dto.request.AuthRequest;
import tech.vuthehuyht.blogrestapi.dto.response.AuthResponse;
import tech.vuthehuyht.blogrestapi.security.CustomUserDetail;
import tech.vuthehuyht.blogrestapi.services.AuthService;
import tech.vuthehuyht.blogrestapi.services.CustomUserDetailService;
import tech.vuthehuyht.blogrestapi.services.JwtService;

import java.util.Collections;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {
    @Autowired
    private AuthenticationManager authenticationManager;
    private final CustomUserDetailService customUserDetailService;
    private final JwtService jwtService;

    @Override
    public AuthResponse login(AuthRequest request) {
        CustomUserDetail userDetail = (CustomUserDetail) customUserDetailService.loadUserByUsername(request.getUsername());

        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword(),
                        Collections.emptyList()
                )
        );

        var accessToken = jwtService.generateToken(userDetail);
        var refreshToken = jwtService.refreshToken(userDetail);

        customUserDetailService.updateLoginAttempt(request.getUsername());

        return new AuthResponse(
                accessToken,
                refreshToken
        );
    }
}
