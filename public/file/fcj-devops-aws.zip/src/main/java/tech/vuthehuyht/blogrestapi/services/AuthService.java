package tech.vuthehuyht.blogrestapi.services;

import tech.vuthehuyht.blogrestapi.dto.request.AuthRequest;
import tech.vuthehuyht.blogrestapi.dto.response.AuthResponse;

public interface AuthService {
    AuthResponse login(AuthRequest request);
}
