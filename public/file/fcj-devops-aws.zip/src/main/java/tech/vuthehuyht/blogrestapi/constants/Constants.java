package tech.vuthehuyht.blogrestapi.constants;

public interface Constants {
    String SUC_MSG= "success";

    String SUC_CODE = "200";

    String BLOCK = "block";

    String ACTIVE = "active";
}
